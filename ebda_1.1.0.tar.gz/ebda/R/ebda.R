#' Calcula a moda, caso exista
#' @param x sequência de números reais
#' @return a moda, se existir.
#' @export
#' @examples
#' # Exemplo de uso da função mo
#' x<-c(1,1,1,0,2)
#' moda(x) # Retorna 1
moda<-function(x){
  tab.unico<-unique(x)
  tab.comb<-match(x,tab.unico)
  tab.cont<-tabulate(tab.comb)
  mo.x<-tab.unico[which(tab.cont==max(tab.cont))]
  if (length(mo.x) > 1){
    return("Não há moda")
  } else {
    return(mo.x)
  }
}

#' Calcula o segundo coeficiente de assimetria de Pearson
#' @param x sequência de números reais
#' @return o segundo coeficiente de assimetria de Pearson
#' @export
assimetria<-function(x){
  xbarra<-mean(x)
  md<-median(x)
  s<-sd(x)
  return((3*(xbarra - md))/s)
}

#' Calcula o coeficiente percentílico de curtose
#' @param x sequência de números reais
#' @return coeficiente percentílico de curtose
#' @export
curtose<-function(x){
  q1<-quantile(x,0.25,type = 2)
  q3<-quantile(x,0.75,type = 2)
  p10<-quantile(x,0.10,type = 2)
  p90<-quantile(x,0.90,type = 2)
  return((q3 - q1)/(2*(p90 - p10)))
}

#' Determina a tabela de distribuição de frequências absolutas
#' @param x sequência de números reais
#' @param op 1 (TRUE) inclui o limite superior e exclui o inferior em cada classe
#' @param op 0 (FALSE) exclui o limite superior e inclui o inferior em cada classe
#' @return a tabela de distribuição de frequências absolutas
#' @export
cons.DF<-function(x,op){
  intervalo<-max(x)-min(x)
  n<-length(x)
  k<-ceiling(1 + 3.322*log10(n))
  h<-ceiling(intervalo/k)
  L0<-floor(min(x))
  classes<-seq(L0,L0+k*h,h)
  if (op == 1){
    tab<-table(cut(x,classes))
  } else {tab<-table(cut(x,classes,right = FALSE))}
  return(tab)
}

#' Função que, dada uma distribuição de frequências absolutas, constrói um data frame
#' @param k quantidade de classes, número natural maior que 0
#' @param h amplitude de classe, número natural maior que 0
#' @param L0 limite inferior da primeira classe, número real
#' @param fi frequências absolutas de cada classe
#' @return dataframe com as seguintes colunas: limites inferior e superior de cada classe, frequências absolutas,
#' frequências absolutas acumuladas e xi (ponto médio de cada classe)
#' @export
tab.df<-function(k,h,L0,fi){
  li.classes<-seq(L0,L0+(k-1)*h,h)
  ls.classes<-seq(L0+h,L0+k*h,h)
  n<-sum(fi)
  fac<-cumsum(fi)
  xi<-NULL
  for(i in 1:k) xi[i]<-(li.classes[i] + ls.classes[i])/2
  return(data.frame(li.classes,ls.classes, fi, fac, xi))
}

#' Calcula a média aritmética de uma tabela de distribuição de frequências absolutas
#' @param x tabela de distribuição de frequências absolutas gerada pela função tab.df(k,h,L0,fi)
#' @return a média aritmética
#' @export
m.a<-function(x){
  n<-sum(x$fi)
  fi.xi<-x$fi*x$xi
  return(sum(fi.xi)/n)
}

#' Calcula a variância amostral de uma tabela de distribuição de frequências absolutas
#' @param x tabela de distribuição de frequências absolutas gerada pela função tab.df(k,h,L0,fi)
#' @return a variância amostral
#' @export
m.var<-function(x){
  n<-sum(x$fi)
  xbarra<-m.a(x)
  return(sum(x$fi*(x$xi-xbarra)^2)/(n-1))
}

#' Calcula o desvio médio absoluto de uma tabela de distribuição de frequências absolutas
#' @param x tabela de distribuição de frequências absolutas gerada pela função tab.df(k,h,L0,fi)
#' @return o desvio médio absoluto
#' @export
m.dma<-function(x){
  n<-sum(x$fi)
  xbarra<-m.a(x)
  return(sum(x$fi*abs(x$xi - xbarra))/n)
}

#' Calcula a moda (Fórmula de Czuber), caso exista, de uma tabela de distribuição de frequências absolutas
#' @param x tabela de distribuição de frequências absolutas gerada pela função tab.df(k,h,L0,fi)
#' @return a moda, caso exista
#' @export
Mo<-function(x){
  k<-nrow(x)
  linha<-which(x[,3]==max(x[,3]))

  if (length(linha) > 1){
    return("Não há moda")
  }else{
    if (linha == 1 ){
      delta1<- x[linha, 3]
      delta2<- x[linha, 3] - x[linha + 1, 3]
    }
    if (linha == k){
      delta1<- x[linha, 3] - x[linha - 1, 3]
      delta2<- x[linha, 3]
    }
    if ((linha != 1) && (linha != k)){
      delta1<- x[linha, 3] - x[linha - 1, 3]
      delta2<- x[linha, 3] - x[linha + 1, 3]
    }
    return(x[linha,1] + (delta1/(delta1 +delta2))*h)
  }
}

#' Calcula um quantil de uma tabela de distribuição de frequências absolutas
#' @param x tabela de distribuição de frequências absolutas gerada pela função tab.df(k,h,L0,fi)
#' @param i posição do quantil desejado (Ex. P25, i = 25)
#' @param m quantidade de partições (Ex. P25, m = 100)
#' @return o quantil
#' @export
m.s<-function(x,i,m){
  n<-sum(x[,3])
  pos <- (i*n)/m
  linha<-which(pos<=x[,4])[1]
  if (linha == 1){
    return (x[linha,1] + (pos/x[linha,3])*h)
  }
  else
    return(x[linha,1] + (((pos - x[linha - 1, 4]))/x[linha,3])*h)
}

#' Calcula o segundo coeficiente de Pearson de assimetria para uma distribuição de frequências absolutas
#' @param x tabela de distribuição de frequências absolutas gerada pela função tab.df(k,h,L0,fi)
#' @return o segundo coeficiente de Pearson de assimetria
#' @export
m.As<-function(x){
  xbarra<-m.a(x)
  md<-m.s(x,2,4)
  s<-sqrt(m.var(x))
  return((3*(xbarra - md))/s)
}

#' Calcula o coeficiente percentílico de curtose para uma distribuição de frequências absolutas
#' @param x tabela de distribuição de frequências absolutas gerada pela função tab.df(k,h,L0,fi)
#' @return o coeficiente percentílico de curtose
#' @export
m.curtose<-function(x){
  q1<-m.s(x,1,4)
  q3<-m.s(x,3,4)
  p10<-m.s(x,10,100)
  p90<-m.s(x,90,100)
  return((q3 - q1)/(2*(p90 - p10)))
}
